package work;

public class Test02 {
    public static void main(String[] args) {

    }
}
