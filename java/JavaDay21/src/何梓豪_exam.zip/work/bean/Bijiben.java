package work.bean;

public class Bijiben extends EGoods {
    public Bijiben() {
    }

    public Bijiben(int id, String name, int price) {
        super(id, name, price);
    }
}
