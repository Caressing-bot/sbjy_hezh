package work.bean;

public class EGoods extends Goods {
    public EGoods() {
    }

    public EGoods(int id, String name, int price) {
        super(id, name, price);
    }
}
