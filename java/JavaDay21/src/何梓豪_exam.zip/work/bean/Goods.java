package work.bean;

public class Goods {
    public int id;
    public String name;
    public int price;
    public Goods(){

    }

    public Goods(int id, String name, int price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}
