package work.bean;

public class Phone extends EGoods  {
    public Phone() {
    }

    public Phone(int id, String name, int price) {
        super(id, name, price);
    }
}
