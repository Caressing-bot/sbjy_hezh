public class Test05 {
    public static void main(String[] args) {
        System.out.println("8的绝对值："+Math.abs(8));
        System.out.println("-9的绝对值："+Math.abs(-9));
        System.out.println("6.1向上取整的值"+Math.ceil(6.1));
        System.out.println("-6.1向上取整的值"+Math.ceil(-6.1));
        System.out.println("6.8向下取整的值"+Math.floor(6.8));
        System.out.println("-6.8向下取整的值"+Math.floor(-6.8));
        System.out.println("5.88四舍五入的值"+Math.round(5.88));
        System.out.println("-5.88四舍五入的值"+Math.round(-5.88));
    }
}
