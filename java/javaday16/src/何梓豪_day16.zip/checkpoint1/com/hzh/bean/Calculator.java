package checkpoint1.com.hzh.bean;

public interface Calculator {
    int calc(int a, int b);
}
