package checkpoint1.com.hzh.bean;

public interface Director {
    void makeMovie();
}
