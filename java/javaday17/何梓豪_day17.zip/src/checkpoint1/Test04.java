package checkpoint1;

import java.io.File;

public class Test04 {
    public static void main(String[] args) {
        File f1 = new File("C:\\ccc\\bbb\\aaa");
        f1.mkdirs();
    }
}
